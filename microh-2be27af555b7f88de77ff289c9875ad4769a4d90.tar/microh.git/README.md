![yourls](http://yourls.org/images/yourls-logo.png)
[YOURLS](http://yourls.org)
======
**YOURLS** is a set of PHP script that will allow you to run your own URL shortener. You'll have full control over your data, detailed stats and analytics, plugins, and more. It's free.

Useful links
------------
* [Project home & doc](http://yourls.org)
* [Official blog](http://blog.yourls.org)
* [Wiki documentation](https://github.com/YOURLS/YOURLS/wiki/)
* [Issue tracker](https://github.com/YOURLS/YOURLS/issues)
* [Release archive](https://github.com/YOURLS/YOURLS/tags)

License
-------
Free software. Do whatever the hell you want with it.
