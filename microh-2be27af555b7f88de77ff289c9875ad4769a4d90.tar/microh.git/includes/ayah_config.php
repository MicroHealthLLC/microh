<?php
// Edit the two lines below to use the keys for your site.
// (Note: you can find your keys at http://portal.areyouahuman.com/dashboard)
define( 'AYAH_PUBLISHER_KEY', '1fc17789adcf43ca6086c1b341ea09d3c71c1636');
define( 'AYAH_SCORING_KEY', '2d40a028641cae8289713f02530d514ba07f82a2');


// Set defaults for values needed by the ayah.php file.
// (Note: you do not need to change these.)
define( 'AYAH_WEB_SERVICE_HOST', 'ws.areyouahuman.com');
define( 'AYAH_TIMEOUT', 0);
define( 'AYAH_DEBUG_MODE', FALSE);
define( 'AYAH_USE_CURL', TRUE);
